const pool = require('../config/db');
const { calculateFare } = require('../utils/fareCalculator');

// GET /api/customer/estimate  -- quick fare preview before booking
async function estimateFare(req, res) {
  try {
    const { vehicle_type, distance_km, goods_weight_kg } = req.body;
    if (!vehicle_type || !distance_km || !goods_weight_kg) {
      return res.status(400).json({ message: 'vehicle_type, distance_km, goods_weight_kg are required' });
    }
    const price = calculateFare(vehicle_type, Number(distance_km), Number(goods_weight_kg));
    res.json({ estimated_price: price });
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
}

// POST /api/customer/bookings -- place a new transport request
async function createBooking(req, res) {
  try {
    const customerId = req.user.id;
    const {
      pickup_location,
      delivery_location,
      distance_km,
      vehicle_type,
      goods_description,
      goods_weight_kg
    } = req.body;

    if (!pickup_location || !delivery_location || !vehicle_type || !goods_description || !goods_weight_kg) {
      return res.status(400).json({ message: 'Missing required booking fields' });
    }

    const estimatedPrice = calculateFare(
      vehicle_type,
      Number(distance_km) || 0,
      Number(goods_weight_kg)
    );

    const [result] = await pool.query(
      `INSERT INTO bookings
        (customer_id, pickup_location, delivery_location, distance_km, vehicle_type, goods_description, goods_weight_kg, estimated_price, status)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'pending')`,
      [customerId, pickup_location, delivery_location, distance_km || null, vehicle_type, goods_description, goods_weight_kg, estimatedPrice]
    );

    await pool.query(
      `INSERT INTO booking_status_history (booking_id, status, changed_by) VALUES (?, 'pending', 'customer')`,
      [result.insertId]
    );

    const [rows] = await pool.query('SELECT * FROM bookings WHERE id = ?', [result.insertId]);
    res.status(201).json({ booking: rows[0] });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error creating booking' });
  }
}

// GET /api/customer/bookings -- all bookings for the logged-in customer
async function getMyBookings(req, res) {
  try {
    const [rows] = await pool.query(
      `SELECT b.*, d.name AS driver_name, d.phone AS driver_phone
       FROM bookings b
       LEFT JOIN drivers d ON b.driver_id = d.id
       WHERE b.customer_id = ?
       ORDER BY b.created_at DESC`,
      [req.user.id]
    );
    res.json({ bookings: rows });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error fetching bookings' });
  }
}

// GET /api/customer/bookings/:id -- single booking detail (must belong to this customer)
async function getBookingById(req, res) {
  try {
    const [rows] = await pool.query(
      `SELECT b.*, d.name AS driver_name, d.phone AS driver_phone
       FROM bookings b
       LEFT JOIN drivers d ON b.driver_id = d.id
       WHERE b.id = ? AND b.customer_id = ?`,
      [req.params.id, req.user.id]
    );
    if (rows.length === 0) return res.status(404).json({ message: 'Booking not found' });
    res.json({ booking: rows[0] });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error fetching booking' });
  }
}

module.exports = { estimateFare, createBooking, getMyBookings, getBookingById };
