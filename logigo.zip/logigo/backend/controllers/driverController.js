const pool = require('../config/db');

// GET /api/driver/bookings -- deliveries assigned to this driver
async function getAssignedBookings(req, res) {
  try {
    const [rows] = await pool.query(
      `SELECT b.*, c.name AS customer_name, c.phone AS customer_phone
       FROM bookings b
       JOIN customers c ON b.customer_id = c.id
       WHERE b.driver_id = ?
       ORDER BY b.created_at DESC`,
      [req.user.id]
    );
    res.json({ bookings: rows });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error fetching assigned bookings' });
  }
}

// PATCH /api/driver/bookings/:id/respond -- accept or reject an assignment
async function respondToBooking(req, res) {
  try {
    const { action } = req.body; // 'accept' | 'reject'
    if (!['accept', 'reject'].includes(action)) {
      return res.status(400).json({ message: "action must be 'accept' or 'reject'" });
    }

    const [rows] = await pool.query(
      'SELECT * FROM bookings WHERE id = ? AND driver_id = ?',
      [req.params.id, req.user.id]
    );
    if (rows.length === 0) return res.status(404).json({ message: 'Booking not found' });
    if (rows[0].status !== 'assigned') {
      return res.status(400).json({ message: 'Only bookings in "assigned" status can be responded to' });
    }

    const newStatus = action === 'accept' ? 'accepted' : 'rejected';
    await pool.query('UPDATE bookings SET status = ? WHERE id = ?', [newStatus, req.params.id]);

    // If rejected, free the driver and unassign so admin can reassign
    if (action === 'reject') {
      await pool.query('UPDATE bookings SET driver_id = NULL WHERE id = ?', [req.params.id]);
      await pool.query('UPDATE drivers SET status = "available" WHERE id = ?', [req.user.id]);
    }

    await pool.query(
      `INSERT INTO booking_status_history (booking_id, status, changed_by) VALUES (?, ?, 'driver')`,
      [req.params.id, newStatus]
    );

    res.json({ message: `Booking ${newStatus}` });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error responding to booking' });
  }
}

// PATCH /api/driver/bookings/:id/status -- move a booking through the delivery lifecycle
async function updateDeliveryStatus(req, res) {
  try {
    const { status } = req.body;
    const allowed = ['picked_up', 'in_transit', 'delivered'];
    if (!allowed.includes(status)) {
      return res.status(400).json({ message: `status must be one of: ${allowed.join(', ')}` });
    }

    const [rows] = await pool.query(
      'SELECT * FROM bookings WHERE id = ? AND driver_id = ?',
      [req.params.id, req.user.id]
    );
    if (rows.length === 0) return res.status(404).json({ message: 'Booking not found' });

    // Enforce a sane forward-only sequence
    const sequence = ['accepted', 'picked_up', 'in_transit', 'delivered'];
    const currentIdx = sequence.indexOf(rows[0].status);
    const nextIdx = sequence.indexOf(status);
    if (nextIdx === -1 || nextIdx !== currentIdx + 1) {
      return res.status(400).json({ message: `Cannot move from '${rows[0].status}' to '${status}'` });
    }

    await pool.query('UPDATE bookings SET status = ? WHERE id = ?', [status, req.params.id]);

    if (status === 'delivered') {
      await pool.query('UPDATE drivers SET status = "available" WHERE id = ?', [req.user.id]);
    }

    await pool.query(
      `INSERT INTO booking_status_history (booking_id, status, changed_by) VALUES (?, ?, 'driver')`,
      [req.params.id, status]
    );

    res.json({ message: `Status updated to ${status}` });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error updating status' });
  }
}

module.exports = { getAssignedBookings, respondToBooking, updateDeliveryStatus };
