const express = require('express');
const router = express.Router();
const { verifyToken, requireRole } = require('../middleware/auth');
const {
  getDashboard,
  getCustomers,
  getDrivers,
  getAllBookings,
  assignDriver,
  changeBookingStatus
} = require('../controllers/adminController');

router.use(verifyToken, requireRole('admin'));

router.get('/dashboard', getDashboard);
router.get('/customers', getCustomers);
router.get('/drivers', getDrivers);
router.get('/bookings', getAllBookings);
router.patch('/bookings/:id/assign', assignDriver);
router.patch('/bookings/:id/status', changeBookingStatus);

module.exports = router;
