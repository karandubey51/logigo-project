const express = require('express');
const router = express.Router();
const { verifyToken, requireRole } = require('../middleware/auth');
const {
  estimateFare,
  createBooking,
  getMyBookings,
  getBookingById
} = require('../controllers/customerController');

router.use(verifyToken, requireRole('customer'));

router.post('/estimate', estimateFare);
router.post('/bookings', createBooking);
router.get('/bookings', getMyBookings);
router.get('/bookings/:id', getBookingById);

module.exports = router;
