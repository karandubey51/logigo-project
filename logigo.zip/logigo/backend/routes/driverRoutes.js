const express = require('express');
const router = express.Router();
const { verifyToken, requireRole } = require('../middleware/auth');
const {
  getAssignedBookings,
  respondToBooking,
  updateDeliveryStatus
} = require('../controllers/driverController');

router.use(verifyToken, requireRole('driver'));

router.get('/bookings', getAssignedBookings);
router.patch('/bookings/:id/respond', respondToBooking);
router.patch('/bookings/:id/status', updateDeliveryStatus);

module.exports = router;
